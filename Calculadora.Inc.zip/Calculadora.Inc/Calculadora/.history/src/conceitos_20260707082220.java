public class conceitos {
    // ATRIBUTOS
    
}
